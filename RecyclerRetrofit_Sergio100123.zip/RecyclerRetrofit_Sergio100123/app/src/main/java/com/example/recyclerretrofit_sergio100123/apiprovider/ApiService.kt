package com.example.recyclerretrofit_sergio100123.apiprovider

import com.example.recyclerretrofit_sergio100123.model.Imagen
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {
    @GET(" ")//api/
    suspend fun  getImage(@Query("key") api_key:String,@Query("q")q:String):Imagen
}