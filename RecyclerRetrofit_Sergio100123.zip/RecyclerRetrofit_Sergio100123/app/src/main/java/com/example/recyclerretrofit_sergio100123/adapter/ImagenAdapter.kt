package com.example.recyclerretrofit_sergio100123.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerretrofit_sergio100123.R
import com.example.recyclerretrofit_sergio100123.model.ImagenData

class ImagenAdapter(var lista:MutableList<ImagenData>,
                    var onItemClick:(ImagenData)->Unit):RecyclerView.Adapter<ImagenViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImagenViewHolder {
        val v= LayoutInflater.from(parent.context).inflate(R.layout.imagen_layout,parent,false)
        return ImagenViewHolder(v)
    }

    override fun onBindViewHolder(holder: ImagenViewHolder, position: Int) {
        holder.render(lista[position],onItemClick)
    }

    override fun getItemCount(): Int {
        return lista.size
    }
}