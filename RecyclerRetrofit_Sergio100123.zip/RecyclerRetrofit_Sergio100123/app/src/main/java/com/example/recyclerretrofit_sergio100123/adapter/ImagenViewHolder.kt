package com.example.recyclerretrofit_sergio100123.adapter

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.example.recyclerretrofit_sergio100123.databinding.ImagenLayoutBinding
import com.example.recyclerretrofit_sergio100123.model.Imagen
import com.example.recyclerretrofit_sergio100123.model.ImagenData
import com.squareup.picasso.Picasso

class ImagenViewHolder(v: View): RecyclerView.ViewHolder(v)  {
    private val binding =ImagenLayoutBinding.bind(v)

      fun render(img:ImagenData,onItemClick:(ImagenData)->Unit){

        binding.tvUsuario.text=img.user
        binding.tvLikes.text= img.likes.toString()
        Picasso.get().load(img.previewURL).into(binding.imageView)
          itemView.setOnClickListener(){
              onItemClick(img)
          }
    }

}
