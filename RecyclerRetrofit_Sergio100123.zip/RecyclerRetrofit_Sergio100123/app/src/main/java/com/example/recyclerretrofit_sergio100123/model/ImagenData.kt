package com.example.recyclerretrofit_sergio100123.model

data class ImagenData(

    val likes: Int,
    val user: String,
    val previewURL: String

):java.io.Serializable