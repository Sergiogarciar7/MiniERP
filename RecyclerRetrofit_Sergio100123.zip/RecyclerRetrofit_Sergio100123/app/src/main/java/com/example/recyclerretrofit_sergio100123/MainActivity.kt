package com.example.recyclerretrofit_sergio100123

import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.*
import android.widget.SearchView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.example.recyclerretrofit_sergio100123.adapter.ImagenAdapter
import com.example.recyclerretrofit_sergio100123.apiprovider.ApiClient
import com.example.recyclerretrofit_sergio100123.databinding.ActivityMainBinding
import com.example.recyclerretrofit_sergio100123.model.ImagenData
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    var lista= mutableListOf<ImagenData>()
    lateinit var adapter: ImagenAdapter
    var key=""
    var q=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        key=getString(R.string.api_key)
        setTitle("Pixabay Sergio")
        setRecycler()

        initListeners()
    }
    private fun setRecycler() {
        val layoutmanager= GridLayoutManager(this,1)
        binding.RecFotos.layoutManager=layoutmanager
        adapter=ImagenAdapter (lista,{onItemClick(it)})
        binding.RecFotos.adapter=adapter
        traerImagen()
    }
    private fun traerImagen() {
        lifecycleScope.launch{
            val datos= ApiClient.apiClient.getImage(key,q)
            adapter.lista=datos.hits.toMutableList()
            adapter.notifyDataSetChanged()
        }
    }
    private fun initListeners(){

        //listener para searh view
        binding.SearchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                //quita los espacios en blanco
                q= query?.trim()?.lowercase().toString()
                setRecycler()
                if(q.isEmpty()){
                    return false
                }

                return true
            }

            override fun onQueryTextChange(p0: String?): Boolean {
                return false
            }

        })
    }
    private fun onItemClick(img:ImagenData) {
        val i= Intent(this,DetallesActivity::class.java).apply {
            putExtra("IMG",img)

        }
        startActivity(i)
    }

}