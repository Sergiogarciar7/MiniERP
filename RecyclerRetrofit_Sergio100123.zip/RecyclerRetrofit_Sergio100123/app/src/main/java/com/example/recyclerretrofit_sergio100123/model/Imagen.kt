package com.example.recyclerretrofit_sergio100123.model

data class Imagen (
    val hits: List<ImagenData>
        )