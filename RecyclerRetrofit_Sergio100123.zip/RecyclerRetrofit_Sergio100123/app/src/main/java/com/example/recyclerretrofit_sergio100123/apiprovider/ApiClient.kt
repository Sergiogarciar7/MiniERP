package com.example.recyclerretrofit_sergio100123.apiprovider

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {
    private val retrofit= Retrofit.Builder()
        .baseUrl("https://pixabay.com/api/")
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiClient = retrofit.create(ApiService::class.java)
}