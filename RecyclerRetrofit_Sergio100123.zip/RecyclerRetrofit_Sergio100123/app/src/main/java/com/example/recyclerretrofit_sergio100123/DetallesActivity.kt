package com.example.recyclerretrofit_sergio100123

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.recyclerretrofit_sergio100123.databinding.ActivityDetallesBinding
import com.example.recyclerretrofit_sergio100123.model.ImagenData
import com.squareup.picasso.Picasso

class DetallesActivity : AppCompatActivity() {
    lateinit var binding: ActivityDetallesBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityDetallesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        cogerDatos()
    }
    private fun cogerDatos() {
        val datos= intent.extras
        val Img= datos?.getSerializable("IMG") as ImagenData
        Picasso.get().load(Img.previewURL).into(binding.imageView2)
        binding.textView.text=Img.user
        binding.textView2.text=Img.likes.toString()
    }
}